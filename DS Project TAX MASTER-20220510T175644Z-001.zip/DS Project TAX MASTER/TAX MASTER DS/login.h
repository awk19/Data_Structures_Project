#include<iostream>
#include<fstream>
using namespace std;
#ifndef LOGIN_H
#define LOGIN_H
inline bool login();
#endif
